.onAttach <- function(lib, pkg){

  packageStartupMessage("\n")
  packageStartupMessage("################################################################################\n")
  packageStartupMessage("Easy Microarray Analysis\n")
  packageStartupMessage("EMA stable version\n")
  packageStartupMessage("Current release : v1.4.4 - march 2014\n")
  packageStartupMessage("################################################################################\n")    
}
